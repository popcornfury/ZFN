For each of the 7 targets, and each stringency, we have a file
target_stringency.txt that specifies a helix binding the target 
by the amino acids obtained in the -1, 2, 3, 5 and 6 positions, 
along with the number of times it was observed.' Positions 1 
and 4 are fixed as Serine and Leucine, respectively.
For example, 'AAG_high.txt' gives helices found to bind AAG at 
high_stringency.